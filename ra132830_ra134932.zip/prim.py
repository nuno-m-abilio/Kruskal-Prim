import heapq
from typing import Dict, List, Optional, Set, Tuple
from leitura_dados import aresta


def prim_lista(adjacencias: Dict[int, List[aresta]], vertices_ids: List[int], r: Optional[int] = None
)-> Tuple[List[aresta], float]:
    '''Algoritmo de Prim usando busca linear para encontrar o próximo vértice (O(n²)). O argumento
    r é o vértice que o algoritmo vai iniciar por. Retorna a tupla (MST, custo_total) onde MST é
    lista de arestas da árvore geradora mínima.'''

    if not vertices_ids:
        return [], 0.0
        
    if r is None:
        r = vertices_ids[0]
    
    peso: Dict[int, float] = {v: float('inf') for v in vertices_ids}
    pred: Dict[int, Optional[int]] = {v: None for v in vertices_ids}
 
    Q: Set[int] = set(vertices_ids)
    
    peso[r] = 0
    mst: List[aresta] = []
    custo_total: float = 0.0
    
    while Q:
        min_peso = float('inf')
        u: Optional[int] = None
        
        for v in Q:
            if peso[v] < min_peso:
                min_peso = peso[v]
                u = v

        if u is None:
            break
            
        Q.remove(u)
        
        predecessor = pred[u]
        
        if predecessor is not None:
            aresta_mst = None
            for a in adjacencias[u]:
                if a.id_v2 == predecessor: 
                    aresta_mst = a
                    break
            
            if aresta_mst:
                mst.append(aresta(id_v1=u, id_v2=predecessor, peso=peso[u]))
                custo_total += peso[u]
            
        for aresta_u_v in adjacencias.get(u, []):
            v = aresta_u_v.id_v2
            w_u_v = aresta_u_v.peso
            
            if v in Q and w_u_v < peso[v]:
                pred[v] = u
                peso[v] = w_u_v
                
    return mst, custo_total

def prim_heap(adjacencias: Dict[int, List[aresta]], vertices_ids: List[int], r: Optional[int] = None
) -> Tuple[List[aresta], float]:
    '''Algoritmo de Prim usando Min-Heap (Fila de Prioridade) para encontrar o próximo vértice
    (O(m log n)). O argumento r é o vértice que o algoritmo vai iniciar por. Retorna a tupla
    (MST, custo_total) onde MST é lista de arestas da árvore geradora mínima.'''
    
    if not vertices_ids:
        return [], 0.0
        
    if r is None:
        r = vertices_ids[0]

    peso: Dict[int, float] = {v: float('inf') for v in vertices_ids}
    pred: Dict[int, Optional[int]] = {v: None for v in vertices_ids}
    
    Q: List[Tuple[float, int]] = []
    
    peso[r] = 0
    for v in vertices_ids:
        heapq.heappush(Q, (peso[v], v))
        
    mst: List[aresta] = []
    custo_total: float = 0.0
    
    na_mst: Set[int] = set()
    
    while Q and len(na_mst) < len(vertices_ids):
        w_u, u = heapq.heappop(Q)
        
        if u in na_mst:
            continue
            
        na_mst.add(u)
        
        predecessor = pred[u]
        
        if predecessor is not None:
            mst.append(aresta(id_v1=u, id_v2=predecessor, peso=peso[u]))
            custo_total += peso[u]
            
        for aresta_u_v in adjacencias.get(u, []):
            v = aresta_u_v.id_v2
            w_u_v = aresta_u_v.peso
            
            if v not in na_mst and w_u_v < peso[v]:
                pred[v] = u
                peso[v] = w_u_v
                heapq.heappush(Q, (peso[v], v))
                
    return mst, custo_total